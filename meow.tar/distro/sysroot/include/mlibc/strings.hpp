#ifndef MLIBC_STRINGS
#define MLIBC_STRINGS

#include <bits/size_t.h>
#include <mlibc/locale.hpp>

namespace mlibc {

int strncasecmp(const char *a, const char *b, size_t size, localeinfo *l = getActiveLocale());
size_t strnlen(const char *s, size_t n);
size_t strlcpy(char *d, const char *s, size_t n);
char *stpncpy(char *__restrict dest, const char *__restrict src, size_t n);

} // namespace mlibc

#endif // MLIBC_STRINGS
