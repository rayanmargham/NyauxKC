
#ifndef _DIRENT_H
#define _DIRENT_H

#include <mlibc-config.h>

#include <abi-bits/limits.h>
#include <abi-bits/ino_t.h>
#include <bits/off_t.h>
#include <bits/size_t.h>
#include <bits/ssize_t.h>
#include <bits/reclen_t.h>
#include <bits/types.h>

#ifdef __cplusplus
extern "C" {
#endif

#define DT_UNKNOWN 0
#define DT_FIFO 1
#define DT_CHR 2
#define DT_DIR 4
#define DT_BLK 6
#define DT_REG 8
#define DT_LNK 10
#define DT_SOCK 12
#define DT_WHT 14

/* The character array d_name is of unspecified size, but the number of bytes preceding
 * the terminating null byte will not exceed {NAME_MAX}. */
#define __MLIBC_DIRENT_BODY ino_t d_ino; \
			off_t d_off; \
			reclen_t d_reclen; \
			unsigned char d_type; \
			char d_name[__MLIBC_NAME_MAX+1];

struct dirent {
	__MLIBC_DIRENT_BODY
};

struct posix_dent {
	__MLIBC_DIRENT_BODY
};

#define d_fileno d_ino

#if defined(_DEFAULT_SOURCE)
#define IFTODT(mode) (((mode) & 0170000) >> 12)
#define DTTOIF(dirtype) ((dirtype) << 12)
#endif

struct __mlibc_dir_struct {
	/* the dirfd */
	int __handle;
	/* offset into __ent_buffer for the next dirent */
	__mlibc_size __ent_next;
	/* valid byte count for __ent_buffer */
	__mlibc_size __ent_limit;
	char __ent_buffer[2048];
	/* cached current dirent */
	struct dirent __current;
	/* current seek offset; should be equivalent to lseek(dirfd, 0, SEEK_CUR) */
	long __seek_offset;
};

typedef struct __mlibc_dir_struct DIR;

#ifndef __MLIBC_ABI_ONLY

int alphasort(const struct dirent **__a, const struct dirent **__b);
int closedir(DIR *__dirp);
int dirfd(DIR *__dirp);
DIR *fdopendir(int __fd);
DIR *opendir(const char *__pathname);
struct dirent *readdir(DIR *__dirp);
int readdir_r(DIR *__restrict __dirp, struct dirent *__restrict __entry, struct dirent **__restrict __res);
void rewinddir(DIR *__dirp);
int scandir(const char *__pathname, struct dirent ***__res, int (*__select)(const struct dirent *__entry),
		int (*__compare)(const struct dirent **__a, const struct dirent **__b));
ssize_t posix_getdents(int __fildes, void *__buf, size_t __nbyte, int __flags);

#if __MLIBC_LINUX_OPTION && defined(_LARGEFILE64_SOURCE)
struct dirent64 {
	__MLIBC_DIRENT_BODY
};

struct dirent64 *readdir64(DIR *__dirp);
int scandir64(const char *__pathname, struct dirent64 ***__res, int (*__select)(const struct dirent64 *__entry),
		int (*__compare)(const struct dirent64 **__a, const struct dirent64 **__b));
int versionsort64(const struct dirent64 **__a, const struct dirent64 **__b);
#endif /* __MLIBC_LINUX_OPTION && defined(_LARGEFILE64_SOURCE) */

#undef __MLIBC_DIRENT_BODY

#if defined(_DEFAULT_SOURCE) || defined(_XOPEN_SOURCE)
void seekdir(DIR *__dirp, long __loc);
long telldir(DIR *__dirp);
#endif

#if __MLIBC_GLIBC_OPTION && defined(_GNU_SOURCE)
int versionsort(const struct dirent **__a, const struct dirent **__b);
ssize_t getdents64(int __fd, void *__dirp, size_t __count);
#endif /* __MLIBC_GLIBC_OPTION && defined(_GNU_SOURCE) */

#endif /* !__MLIBC_ABI_ONLY */

#ifdef __cplusplus
}
#endif

#endif /* _DIRENT_H */

